# msrpce/raw

This folder contains partial definitions of Windows IDLs.
