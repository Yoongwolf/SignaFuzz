# utils/protocols/ss7_layers.py
from scapy.all import Packet, StrLenField, IntField, ShortField, ByteField

class SCCP_UDT(Packet):
    name = "SCCP_UDT"
    fields_desc = [
        ByteField("msg_type", 0x09),
        ByteField("protocol_class", 0x00),
        ByteField("pointer1", 0x03),
        ByteField("pointer2", 0x00),
        ByteField("pointer3", 0x00),
        ShortField("called_len", 0),
        ShortField("calling_len", 0),
        ShortField("data_len", 0),
        StrLenField("called_party", b"", length_from=lambda pkt: pkt.called_len),
        StrLenField("calling_party", b"", length_from=lambda pkt: pkt.calling_len),
        StrLenField("data", b"", length_from=lambda pkt: pkt.data_len)
    ]

class TCAP_Invoke(Packet):
    name = "TCAP_Invoke"
    fields_desc = [
        ByteField("tag", 0x02),
        ByteField("component_len", 0),
        ByteField("invoke_tag", 0x0C),
        ByteField("invoke_len", 0),
        ByteField("invoke_id", 0x02),
        ByteField("opcode_tag", 0x02),
        ByteField("opcode_len", 0x01),
        ByteField("opcode", 0x04)
    ]

class TCAP_ReturnResultLast(Packet):
    name = "TCAP_ReturnResultLast"
    fields_desc = [
        ByteField("tag", 0x04),
        ByteField("component_len", 0),
        ByteField("return_result_tag", 0x0C),
        ByteField("return_result_len", 0),
        ByteField("invoke_id", 0x02),
        ByteField("sequence_tag", 0x30),
        ByteField("sequence_len", 0),
        ByteField("opcode_tag", 0x02),
        ByteField("opcode_len", 0x01),
        ByteField("opcode", 0x04)
    ]

class MAP_SRI(Packet):
    name = "MAP_SRI"
    fields_desc = [
        ByteField("tag", 0x30),
        ByteField("len", 0x13),
        ByteField("imsi_tag", 0x80),
        ByteField("imsi_len", 0x08),
        StrLenField("imsi", b"", length_from=lambda pkt: pkt.imsi_len),
        ByteField("msisdn_tag", 0x81),
        ByteField("msisdn_len", 0x05),
        StrLenField("msisdn", b"", length_from=lambda pkt: pkt.msisdn_len)
    ]

class MAP_ATI(Packet):
    name = "MAP_ATI"
    fields_desc = [
        ByteField("tag", 0x30),
        ByteField("len", 0x0A),
        ByteField("imsi_tag", 0x80),
        ByteField("imsi_len", 0x08),
        StrLenField("imsi", b"", length_from=lambda pkt: pkt.imsi_len)
    ]

class MAP_UL(Packet):
    name = "MAP_UL"
    fields_desc = [
        ByteField("tag", 0x30),
        ByteField("len", 0x0F),
        ByteField("imsi_tag", 0x80),
        ByteField("imsi_len", 0x08),
        StrLenField("imsi", b"", length_from=lambda pkt: pkt.imsi_len),
        ByteField("vlr_gt_tag", 0x81),
        ByteField("vlr_gt_len", 0x05),
        StrLenField("vlr_gt", b"", length_from=lambda pkt: pkt.vlr_gt_len)
    ]

class MAP_PSI(Packet):
    name = "MAP_PSI"
    fields_desc = [
        ByteField("tag", 0x30),
        ByteField("len", 0x0A),
        ByteField("imsi_tag", 0x80),
        ByteField("imsi_len", 0x08),
        StrLenField("imsi", b"", length_from=lambda pkt: pkt.imsi_len)
    ]

def set_map_fields(map_packet: Packet, imsi: str = None, msisdn: str = None, vlr_gt: str = None) -> Packet:
    from utils.encoding.bcd import encode_bcd
    if imsi:
        map_packet.imsi = encode_bcd(imsi)
        map_packet.imsi_len = len(map_packet.imsi)
    if msisdn:
        map_packet.msisdn = encode_bcd(msisdn)
        map_packet.msisdn_len = len(map_packet.msisdn)
    if vlr_gt:
        map_packet.vlr_gt = encode_bcd(vlr_gt)
        map_packet.vlr_gt_len = len(map_packet.vlr_gt)
    # Calculate total length for StrLenField fields only
    total_len = 0
    for field in map_packet.fields_desc:
        if isinstance(field, StrLenField):
            value = getattr(map_packet, field.name, b"")
            if value:
                total_len += len(value) + 2  # Include tag and length bytes
    map_packet.len = total_len
    return map_packet