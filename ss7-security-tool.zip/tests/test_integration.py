#test/test_Integration.py
import unittest
from app.core import SS7Core
from app.message_factory import MessageFactory
from app.sctp_client import SCTPClient
from utils.protocols.ss7_layers import SCCP_UDT, TCAP_Invoke

class TestIntegration(unittest.TestCase):
    def setUp(self):
        self.core = SS7Core(api_key="test_key_123")
        self.target_ip = "127.0.0.1"
        self.target_port = 2905
        self.ssn = 6
        self.gt = "1234567890"
        self.imsi = "123456789012345"
        self.msisdn = "9876543210"
        self.vlr_gt = "9876543210"

    def test_sri_workflow(self):
        """Test end-to-end SRI message sending and response parsing."""
        response = self.core.send_sri(
            imsi=self.imsi,
            msisdn=self.msisdn,
            target_ip=self.target_ip,
            target_port=self.target_port,
            ssn=self.ssn,
            gt=self.gt,
            protocol="SCTP"
        )
        self.assertEqual(response["status"], "success")
        self.assertIn("params", response)
        self.assertEqual(response["params"]["imsi"], self.imsi)
        self.assertEqual(response["params"]["msisdn"], self.msisdn)

    def test_ati_workflow(self):
        """Test end-to-end ATI message sending and response parsing."""
        response = self.core.send_ati(
            imsi=self.imsi,
            target_ip=self.target_ip,
            target_port=self.target_port,
            ssn=self.ssn,
            gt=self.gt,
            protocol="SCTP"
        )
        self.assertEqual(response["status"], "success")
        self.assertIn("params", response)
        self.assertEqual(response["params"]["imsi"], self.imsi)

    def test_ul_workflow(self):
        """Test end-to-end UL message sending and response parsing."""
        response = self.core.send_ul(
            imsi=self.imsi,
            vlr_gt=self.vlr_gt,
            target_ip=self.target_ip,
            target_port=self.target_port,
            ssn=self.ssn,
            gt=self.gt,
            protocol="SCTP"
        )
        self.assertEqual(response["status"], "success")
        self.assertIn("params", response)
        self.assertEqual(response["params"]["imsi"], self.imsi)
        self.assertEqual(response["params"]["vlr_gt"], self.vlr_gt)

    def test_psi_workflow(self):
        """Test end-to-end PSI message sending and response parsing."""
        response = self.core.send_psi(
            imsi=self.imsi,
            target_ip=self.target_ip,
            target_port=self.target_port,
            ssn=self.ssn,
            gt=self.gt,
            protocol="SCTP"
        )
        self.assertEqual(response["status"], "success")
        self.assertIn("params", response)
        self.assertEqual(response["params"]["imsi"], self.imsi)

if __name__ == "__main__":
    unittest.main()