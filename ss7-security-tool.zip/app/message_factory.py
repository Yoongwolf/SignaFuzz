#app/message_factory.py
from scapy.all import raw
from utils.protocols.ss7_layers import SCCP_UDT, TCAP_Invoke, MAP_SRI, MAP_ATI, MAP_UL, MAP_PSI, set_map_fields
from utils.encoding.bcd import encode_bcd

class MessageFactory:
    @staticmethod
    def create_sri_message(imsi: str, msisdn: str, gt: str, ssn: int) -> bytes:
        map_sri = set_map_fields(MAP_SRI(), imsi, msisdn)
        tcap = TCAP_Invoke(invoke_id=2, opcode=4)
        sccp = SCCP_UDT(
            called_party=encode_bcd(gt),
            calling_party=encode_bcd("2143658709"),
            called_len=len(encode_bcd(gt)),
            calling_len=5,
            data_len=len(raw(tcap / map_sri))
        )
        return raw(sccp / tcap / map_sri)

    @staticmethod
    def create_ati_message(imsi: str, gt: str, ssn: int) -> bytes:
        map_ati = set_map_fields(MAP_ATI(), imsi)
        tcap = TCAP_Invoke(invoke_id=2, opcode=71)
        sccp = SCCP_UDT(
            called_party=encode_bcd(gt),
            calling_party=encode_bcd("2143658709"),
            called_len=len(encode_bcd(gt)),
            calling_len=5,
            data_len=len(raw(tcap / map_ati))
        )
        return raw(sccp / tcap / map_ati)

    @staticmethod
    def create_ul_message(imsi: str, vlr_gt: str, gt: str, ssn: int) -> bytes:
        map_ul = set_map_fields(MAP_UL(), imsi, vlr_gt=vlr_gt)
        tcap = TCAP_Invoke(invoke_id=2, opcode=2)
        sccp = SCCP_UDT(
            called_party=encode_bcd(gt),
            calling_party=encode_bcd("2143658709"),
            called_len=len(encode_bcd(gt)),
            calling_len=5,
            data_len=len(raw(tcap / map_ul))
        )
        return raw(sccp / tcap / map_ul)

    @staticmethod
    def create_psi_message(imsi: str, gt: str, ssn: int) -> bytes:
        map_psi = set_map_fields(MAP_PSI(), imsi)
        tcap = TCAP_Invoke(invoke_id=2, opcode=59)
        sccp = SCCP_UDT(
            called_party=encode_bcd(gt),
            calling_party=encode_bcd("2143658709"),
            called_len=len(encode_bcd(gt)),
            calling_len=5,
            data_len=len(raw(tcap / map_psi))
        )
        return raw(sccp / tcap / map_psi)