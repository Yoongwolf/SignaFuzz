#app/core.py
import logging
from app.sctp_client import SCTPClient
from app.message_factory import MessageFactory
from app.response_parser import ResponseParser
from utils.validators import validate_imsi, validate_msisdn, validate_gt, validate_ssn

class SS7Core:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.message_factory = MessageFactory()
        self.response_parser = ResponseParser()
        self.logger = logging.getLogger(__name__)

    def send_sri(self, imsi: str, msisdn: str, target_ip: str, target_port: int, ssn: int, gt: str, protocol: str) -> dict:
        if not all([validate_imsi(imsi), validate_msisdn(msisdn), validate_gt(gt), validate_ssn(ssn)]):
            return {"status": "error", "message": "Invalid input parameters"}
        
        packet = self.message_factory.create_sri_message(imsi, msisdn, gt, ssn)
        return self._send_packet(packet, "SRI", target_ip, target_port, {"imsi": imsi, "msisdn": msisdn, "gt": gt, "ssn": ssn, "target_ip": target_ip, "target_port": target_port, "protocol": protocol})

    def send_ati(self, imsi: str, target_ip: str, target_port: int, ssn: int, gt: str, protocol: str) -> dict:
        if not all([validate_imsi(imsi), validate_gt(gt), validate_ssn(ssn)]):
            return {"status": "error", "message": "Invalid input parameters"}
        
        packet = self.message_factory.create_ati_message(imsi, gt, ssn)
        return self._send_packet(packet, "ATI", target_ip, target_port, {"imsi": imsi, "gt": gt, "ssn": ssn, "target_ip": target_ip, "target_port": target_port, "protocol": protocol})

    def send_ul(self, imsi: str, vlr_gt: str, target_ip: str, target_port: int, ssn: int, gt: str, protocol: str) -> dict:
        if not all([validate_imsi(imsi), validate_gt(gt), validate_gt(vlr_gt), validate_ssn(ssn)]):
            return {"status": "error", "message": "Invalid input parameters"}
        
        packet = self.message_factory.create_ul_message(imsi, vlr_gt, gt, ssn)
        return self._send_packet(packet, "UL", target_ip, target_port, {"imsi": imsi, "vlr_gt": vlr_gt, "gt": gt, "ssn": ssn, "target_ip": target_ip, "target_port": target_port, "protocol": protocol})

    def send_psi(self, imsi: str, target_ip: str, target_port: int, ssn: int, gt: str, protocol: str) -> dict:
        if not all([validate_imsi(imsi), validate_gt(gt), validate_ssn(ssn)]):
            return {"status": "error", "message": "Invalid input parameters"}
        
        packet = self.message_factory.create_psi_message(imsi, gt, ssn)
        return self._send_packet(packet, "PSI", target_ip, target_port, {"imsi": imsi, "gt": gt, "ssn": ssn, "target_ip": target_ip, "target_port": target_port, "protocol": protocol})

    def _send_packet(self, packet: bytes, operation: str, target_ip: str, target_port: int, request_data: dict) -> dict:
        try:
            with SCTPClient(target_ip, target_port) as client:
                client.send(packet)
                response = client.receive()
            parsed_response = self.response_parser.parse_response(response)
            self.response_parser.save_transaction(operation, request_data, packet.hex(), response.hex() if response else "", parsed_response)
            return parsed_response
        except Exception as e:
            self.logger.error(f"Error sending {operation} message: {e}")
            parsed_response = {"status": "error", "message": str(e)}
            self.response_parser.save_transaction(operation, request_data, packet.hex(), "", parsed_response)
            return parsed_response

    def get_history(self, limit: int = 10) -> list:
        return self.response_parser.get_history(limit)

    def get_filtered_history(self, operation: str = None, start_date: str = None, end_date: str = None, limit: int = 10) -> list:
        return self.response_parser.get_filtered_history(operation, start_date, end_date, limit)